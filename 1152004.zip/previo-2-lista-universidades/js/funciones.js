function cargarUniversidades()
{
	let url="https://cors-anywhere.herokuapp.com/http://universities.hipolabs.com/search?country=United+Kingdom";
	let m="";
	let table="\n<table class='table table-striped' border='2'>"+
	"\n<thead>"+
	"\n<th scope='col'> Nombre</th>"+
	"\n<th scope='col'> URL</th>"+
	"\n<th scope='col'> QR</th>"+
	"\n</thead>";


	let fila="\n<tr>"+
	"\n<td> @@ </td>"+
	"\n<td> <a href='&&'> &&</a></td>"+
	"\n<td> <img src='https://api.qrserver.com/v1/create-qr-code/?size=150x50&data=&&' /> </td>"+
	"\n</tr>";
	fetch(url, {method:"GET", headers: { origin:"dominio.com" }}).then(response=>response.json()).then(response=>{

		for (var i = 0; i < response.length; i++) {
			m+=fila.replace("@@",response[i].name).replaceAll("&&",response[i].web_pages[0]);
		}

		m=table+m+"\n</table>";
		document.getElementById("universidades").innerHTML=m;

	});


}

/**
 * Función para cargar los datos. Se ejecuta cuando se carga el body del HTML.
 */
function cargarUniversidadesAcordeon(){

	let url="https://programacion-web---i-sem-2019.gitlab.io/persistencia/json_web/json/universidades.json";
	let m="";
	
	var n=0;
	fetch(url).then(response=>response.json()).then(response=>{

		
		n=response.length;
		let url2=new URLSearchParams(location.search);
		//Obtener los values
		let pag=Number(url2.get('pag'));
		
		if(pag!=0)
			pag= (pag*10)-10;
		var y=0;
		
		for ( var i=pag; i <(pag+10) && pag<n && i<n; i++) {
			
			let acor="\n<div class='accordion-item'>"+
			"\n<h2 class='accordion-header' id='flush-heading%%'>"+
			"\n<button class='accordion-button collapsed' type='button' data-bs-toggle='collapse' data-bs-target='#flush-collapse%%' aria-expanded='false' aria-controls='flush-collapse%%'>"+
			"\n@@"+
			"\n</button>"+
			"\n</h2>";
			let lista="\n<div id='flush-collapse%%' class='accordion-collapse collapse' aria-labelledby='flush-heading%%' data-bs-parent='#accordionFlushExample'>"+
			"\n<div class='accordion-body'>"+
			"\n<ul class='datos'>"+
			"\n<li><h3>Web Page:</h3><a href='&&'>&&</a>"+
			"</li>"+
			"\n<li><img src='https://api.qrserver.com/v1/create-qr-code/?size=150x50&data=&&' width='80' height='80'/></li>"+
			"\n<li class='listaAdmin'><div id='admin++' class='lista'></div></li>"+
			"\n</ul>"+
			"\n</div>"+
			"\n</div>";
			
		
			acor=acor.replaceAll("%%",cambiarId(y));
			lista=lista.replaceAll("%%",cambiarId(y));
			lista = lista.replaceAll("++",cambiarId(y));
			cargarAdministrador(y);
			m+=acor.replace("@@",response[i].name);	
			m+=lista.replaceAll("&&",response[i].web_pages[0])+"\n</div>";
			y++;
			
		}

		cargarPaginacion(n,pag);		
		document.getElementById("accordionFlushExample").innerHTML=m;

	});
	
}

/**
 * Crea el elemento de paginación en base a la cantidad de datos cargados. 
 * @param {Number} n Cantidad de datos cargados. 
 * @param {Number} pg Página cargada actualmente. 
 */
function cargarPaginacion(n,pg){

	if(pg==0)
		pg=1;
	else
		pg=(pg+10)/10;
	
	let p ="\n<ul class='pagination'>";
	
	let prev="\n<li class='page-item'>"+
	"\n<a class='page-link' href='./lista_universidades.html?pag="+(pg-1)+"' aria-label='Previous'>"+
	"\n<span aria-hidden='true'>&laquo;"+
	"\n</span>"+
	"\n</a>"+
	"\n</li>";
	
	p+=prev;

	let lim=n/10;	
	if(n%10!=0)
		lim++;


	if(pg==Math.trunc(lim))
		pg--;

	let sig ="\n<li class='page-item'>"+
	"\n<a class='page-link' href='./lista_universidades.html?pag="+(pg+1)+"' aria-label='Next'>"+
	"\n<span aria-hidden='true'>&raquo;"+
	"\n</span>"+
	"\n</a>"+
	"\n</li>";

	
	for(var i=1;i<lim;i++){
		num="<li class='page-item'>"+
		"\n<a class='page-link' href='./lista_universidades.html?pag="+i+"'>"+i+"</a>"+"\n</li>";
		p+=num;
		
	}
	p+=sig+"\n</ul>";
	
	document.getElementById('pag').innerHTML=p;
}

/**
 * Carga los datos del administrador de la universidad usando la API randomuser.me. 
 * @param {Number} y 
 */
function cargarAdministrador(y){
	
	//Tuve que incluir las mismas modificaciones que incialmente se le dieron a la api de universidades, porque me arrojaba un error con el CORS Missing Allow Origin que se solucionó de esta forma. 
	let urlAdmin = "https://cors-anywhere.herokuapp.com/https://randomuser.me/api/";
	y++; //--> Las id de los admin llegan en 0, pero se crean desde 1. Por eso hay que sumar 1.
	
	//En ocaciones funciona correctamente, en otras sin embargo la API responde con error 503. Y tambien es muy común el error 429 Too Many Requests despues de hacer muchas peticiones. 
	fetch(urlAdmin, {method:"GET", headers: { origin:"dominio.com" }}).then(response => response.json()).then(response => {

		let m = "";
		
		m +="\n<ul>"+
		"\n<li><h3>Administrator</h3></li>"+
		"\n<li>Name:<span>"+response.results[0].name.first+" "+response.results[0].name.last+"</span></li>"+
		"\n<li>Email: <span>"+response.results[0].email+"</span></li>"+
		"\n<li>Country: <span>"+response.results[0].location.country+"</span></li>"+
		"\n<li>City: <span>"+response.results[0].location.city+"</span></li>"+
		"\n<li>State: <span>"+response.results[0].location.state+"</span></li>"+
		"\n<li><img src='"+response.results[0].picture.large+"'width='200' height='200'></img></li>"+
		"\n</ul>";

	
		document.getElementById("admin"+y).innerHTML = m;

	})


}

/**
 * Suma uno al identificador i. Esta función se usa para las id de las etiquetas paginación y los acordeones. 
 * @param {Number} i 
 * @returns i. El id para las etiquetas. 
 */
function cambiarId(i){
	i++;
	return String(i);
}
function cargarPerro()
{

	let url="https://dog.ceo/api/breeds/image/random";
	fetch(url).then(response=>response.json()).then(response=>{


		document.getElementById("perro").src=response.message;

	});

}


function leerInputs()
{
	let url=new URLSearchParams(location.search);
	//Obtener los values
	let numeros=url.getAll("numeros");
	let nombre=url.get('nombre');
	let resultado=document.getElementById("resultado");
	cargarPerro();
	resultado.innerHTML="<br>"+nombre+":"+analizar(numeros);

}

function analizar(numeros)
{
	let sum=0;
	for (var i = 0; i<numeros.length; i++) {
		sum+=Number(numeros[i]);
	}
	return sum;

}


function leerURL()
{

	let url=new URLSearchParams(location.search);
		//Obtiene el value:
		let numero=Number(url.get('numero'));
		let nombre=url.get('nombre');

		let resultado=document.getElementById("resultado");
		resultado.innerHTML=crearInput(numero)+inputHidden(nombre);
	}

	function inputHidden(nombre)
	{

		return "<br> <input type='hidden' name='nombre' value='"+nombre+"' />"; 
	}


	function crearInput(n)
	{

		let in2="\t <br> <input type='number' name='numeros' placeholder='Digite dato @@'/>";
		let inputs="";
		for (var i = 0; i <n; i++) {
			inputs+=in2.replace("@@",i);
		}

		return inputs;

	}

	function leer()
	{
		//let numero1=document.getElementsByName("numero1");
		let numero1=document.getElementById("numero1");
		let numero2=document.getElementById("numero2");
		let numero3=document.getElementById("numero3");
		let mensaje=document.getElementById("mensaje");
		let check=document.getElementsByName("operacion");
		let radio=document.getElementsByName("color");


		let msg="Los datos leídos fueron:"+numero1.value+","+numero2.value+","+numero3.value;
		msg+=leerCamposCheck(check,numero1,numero2,numero3);
		msg+="<br> El vector de radio tiene posiciones:"+radio.length;
		msg+="El color seleccionado fue:"+leerCamposRadio(radio);
		numero1.style.backgroundColor = 'yellow';
		numero1.value="";
		numero2.value="";
		numero3.value="";
		mensaje.innerHTML=msg;

	}



	function leerCamposRadio(radio)
	{
		for(let i=0;i<radio.length;i++)
		{
			if(radio[i].checked)
			{

				if(radio[i].value==1)
					return "red";
				else
					return "yellow";
			}

		}

		return "";
	}

	function leerCamposCheck(check,numero1,numero2,numero3)
	{
		let msg="<p>";
		let n1=Number(numero1.value);
		let n2=Number(numero2.value);
		let n3=Number(numero3.value);
		for(let i=0;i<check.length;i++)
		{
			if(check[i].checked)
			{

				if(check[i].value==1)
				{
						//let total=numero1.value+numero2.value+numero3.value;
						let total=n1+n2+n3;
						msg+="&nbsp; Sumando:"+total;
					}
					else
					{
						//let total=numero1.value-numero2.value-numero3.value;
						let total=n1-n2-n3;
						msg+="&nbsp; Restando:"+total;
					}
				}

			}
			return msg+"</p>";	
		}
